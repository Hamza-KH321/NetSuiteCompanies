(function (global) {
    function renderHeader(config) {
        var container = document.getElementById('sharedHeader');
        if (!container) return;

        config = config || {};
        var user = config.user || {};

        container.innerHTML =
            '<header class="app-header">' +
                '<div class="brand">' +
                    '<img id="companyLogo" alt="" class="company-logo hidden">' +
                    '<div class="brand-fallback" id="companyFallback">VS</div>' +
                    '<div>' +
                        '<div class="company-title">' +
                            '<div id="companyName" class="company-name"></div>' +
                            '<span id="sandboxBadge" class="sandbox-badge hidden">SANDBOX</span>' +
                        '</div>' +
                        '<div id="userName" class="user-name"></div>' +
                    '</div>' +
                '</div>' +
                '<nav class="header-actions">' +
                    '<a id="homeButton" class="button-link secondary" href="#">Home</a>' +
                    '<button id="logoutButton" class="ghost" type="button">Logout</button>' +
                '</nav>' +
            '</header>';

        var companyName = document.getElementById('companyName');
        var sandboxBadge = document.getElementById('sandboxBadge');
        var userName = document.getElementById('userName');
        var companyLogo = document.getElementById('companyLogo');
        var companyFallback = document.getElementById('companyFallback');
        var homeButton = document.getElementById('homeButton');
        var logoutButton = document.getElementById('logoutButton');

        companyName.textContent = user.companyName || 'VS Production';
        userName.textContent = user.name || '';
        homeButton.href = config.homeUrl || window.location.href;

        if (user.isSandbox) {
            sandboxBadge.classList.remove('hidden');
        }

        if (user.logoUrl) {
            companyLogo.src = user.logoUrl;
            companyLogo.classList.remove('hidden');
            companyFallback.classList.add('hidden');
        }

        logoutButton.addEventListener('click', function () {
            if (typeof config.onLogout === 'function') {
                config.onLogout();
            }
        });
    }

    global.VSProductionHeader = {
        render: renderHeader
    };
})(window);
