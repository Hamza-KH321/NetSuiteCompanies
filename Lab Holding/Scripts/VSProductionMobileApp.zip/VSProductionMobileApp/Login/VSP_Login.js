(function () {
    var form = document.getElementById('loginForm');
    var errorMessage = document.getElementById('errorMessage');

    form.addEventListener('submit', function (event) {
        event.preventDefault();

        var button = form.querySelector('button[type="submit"]');
        var username = document.getElementById('username').value.trim();
        var password = document.getElementById('password').value;

        errorMessage.textContent = '';

        if (!username || !password) {
            errorMessage.textContent = 'Username and password are required.';
            return;
        }

        button.disabled = true;

        fetch(window.location.href, {
            method: 'POST',
            headers: { 'Content-Type': 'application/x-www-form-urlencoded' },
            body: 'username=' + encodeURIComponent(username) + '&password=' + encodeURIComponent(password)
        })
            .then(function (response) { return response.json(); })
            .then(function (result) {
                if (result && result.success && result.redirectUrl) {
                    window.location.href = result.redirectUrl;
                    return;
                }

                errorMessage.textContent = result && result.message ? result.message : 'Login failed.';
                button.disabled = false;
            })
            .catch(function () {
                errorMessage.textContent = 'Login failed. Please try again.';
                button.disabled = false;
            });
    });
})();
